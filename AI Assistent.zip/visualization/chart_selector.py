import pandas as pd
from pandas.api.types import is_datetime64_any_dtype

def select_chart(result):

    # Rule 1
    if not isinstance(result, pd.DataFrame):
        return None

    # Rule 2
    if len(result.columns) != 2:
        return "bar"

    first_col = result.columns[0]

    # Rule 3
    if is_datetime64_any_dtype(result[first_col]):
        return "line"

    # Rule 4
    if result[first_col].nunique() <= 8:
        return "pie"

    # Rule 5
    return "bar"